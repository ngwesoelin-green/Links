﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCore_2021_04_01.Models
{
    public class MyDataContext : IdentityDbContext
    {
        public MyDataContext(DbContextOptions<MyDataContext> options) : base(options)
        {         
        }
        public DbSet<tblTest1> tblTest1 { get; set; }
    }

   
}
