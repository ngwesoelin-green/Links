﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EDMS.IServices;
using EDMS.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EDMS.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly ItblTest1Service testService;
        public TestController(ItblTest1Service data)
        {
            testService = data;
        }

        //[HttpGet]
        //[Route("[action]")]
        //[Route("api/Test/Get2")]
        //public IEnumerable<tblTest1> Get()
        //{
        //    return testService.Get();
        //}

        [HttpGet]
        public IEnumerable<tblTest1> Get()
        {
            return testService.Get();
        }

        [HttpGet("{id?}/{name?}")]
        public tblTest1 GetByID(int ID, string name)
        {
            return testService.GetByID(ID);
        }

        [HttpPost]
        public tblTest1 Insert(tblTest1 data)
        {
            return testService.Insert(data);
        }

        [HttpPut]
        public tblTest1 Update(tblTest1 data)
        {
            return testService.Update(data);
        }

        [HttpDelete]
        public tblTest1 Delete(int id)
        {
            return testService.Delete(id);
        }


        [HttpPost]
        public tblTest1 UpdateObj(tblTest1 data)
        {
            return testService.UpdateObj(data);
        }
    }
}
