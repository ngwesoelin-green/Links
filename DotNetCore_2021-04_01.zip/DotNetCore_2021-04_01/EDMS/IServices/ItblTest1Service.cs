﻿using EDMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EDMS.IServices
{
    public interface ItblTest1Service
    {
        IEnumerable<tblTest1> Get();
        tblTest1 GetByID(int ID);
        tblTest1 Insert(tblTest1 t);
        tblTest1 Update(tblTest1 t);
        tblTest1 Delete (int ID);

        tblTest1 UpdateObj(tblTest1 t);


    }
}
