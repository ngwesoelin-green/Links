﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EDMS.Models
{
    public partial class tblTest1
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
    }
}
