﻿using EDMS.IServices;
using EDMS.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EDMS.Services
{
    public class tblTest1Service : ItblTest1Service
    {
        TestDBContext dbContext;
        public tblTest1Service(TestDBContext _db)
        {
            dbContext = _db;
        }

        public IEnumerable<tblTest1> Get()
        {
            var data = dbContext.tblTest1s.ToList();
            return data;
        }

        public tblTest1 GetByID(int ID)
        {
            var data = dbContext.tblTest1s.FirstOrDefault(x => x.Id == ID);
            return data;
        }

        public tblTest1 Insert(tblTest1 data)
        {
            if (data != null)
            {
                dbContext.tblTest1s.Add(data);
                dbContext.SaveChanges();
                return data;
            }
            return null;
        }
        public tblTest1 Update(tblTest1 data)
        {
            dbContext.Entry(data).State = EntityState.Modified;
            dbContext.SaveChanges();
            return data;
        }
        public tblTest1 Delete(int ID)
        {
            var data = dbContext.tblTest1s.FirstOrDefault(x => x.Id == ID);
            dbContext.Entry(data).State = EntityState.Deleted;
            dbContext.SaveChanges();
            return data;
        }



        public tblTest1 UpdateObj(tblTest1 data)
        {
            tblTest1 obj = dbContext.tblTest1s.SingleOrDefault(x => x.Id == data.Id);
            obj.Name = data.Name + "_Obj";
            obj.Phone = data.Phone + "_Obj";
            dbContext.SaveChanges();
            return data;
        }
    }
}
